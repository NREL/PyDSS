from pydss.ProfileManager import ProfileInterface
