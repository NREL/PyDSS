
class ControllerAbstract():
    def __init__(self):

        """Abstract class CONSTRUCTOR."""

    def Update(self,  Priority, Time, UpdateResults):
        pass

