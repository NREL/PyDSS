class PlotAbstract():
    def __init__(self):

        """Abstract class CONSTRUCTOR."""

    def UpdatePlot(self):
        pass

