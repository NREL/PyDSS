import pandas as pd
import os

class Plot:

    def __init__(self, resultPath):

        return

    def get_results(self):
        return self.__result_dict